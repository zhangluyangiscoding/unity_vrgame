﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitDispenser : MonoBehaviour
{
    
    public GameObject[] fruits;
    public GameObject bomb;
    public float y;
    public float powerScale;
    public bool pause = false;
    bool started = false;
    public float timer=2.5f;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        if (pause) return;
        timer -= Time.deltaTime;
        if(timer<=0&&!started)
        {
            timer = 0f;
            started = true;
        }
        if(started)
        {
            if (SharedSetting.LoadLevel == 0)
            {
                if (timer <= 0)
                {
                    FireUp();
                    timer = 6.0f;
                }
            }
            else
            if (SharedSetting.LoadLevel == 1)
            {
                if (timer <= 0)
                {
                    FireUp();
                    timer = 2.0f;
                }
            }
            else
            if (SharedSetting.LoadLevel == 2)
            {
                if (timer <= 0)
                {
                    FireUp();
                    timer = 1.75f;
                }
            }
            else
            if (SharedSetting.LoadLevel == 3)
            {
                if (timer <= 0)
                {
                    FireUp();
                    timer = 1.5f;
                }
            }
        }
        //Spawn(false);
        //GameObject go = GameObject.Find("ins");

    }
    void FireUp()
    {
        if (pause) return;
        Spawn(false);
        if(SharedSetting.LoadLevel==2&&Random.Range(0,10)<2)
        {
            Spawn(false);

        }
        if (SharedSetting.LoadLevel == 3 && Random.Range(0, 10) < 4)
        {
            Spawn(false);

        }
        if (SharedSetting.LoadLevel == 1 && Random.Range(0, 100) < 10)
        {
            Spawn(true);

        }
        if (SharedSetting.LoadLevel == 2 && Random.Range(0, 100) < 20)
        {
            Spawn(true);

        }
        if (SharedSetting.LoadLevel == 3 && Random.Range(0, 100) < 30)
        {
            Spawn(true);

        }

    }
    void Spawn(bool isBomb)
    {
        //float x = Random.Range(1.15f, 1.15f);
        //z = Random.Range(2.17f, 2.17f);
        float x = 1.15f;
        y = 1.7f;
        GameObject ins;
        if(!isBomb)
        {
            //transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
            //ins = Instantiate(fruits[Random.Range(0, fruits.Length)], transform.position + new Vector3(x, 1,0), Random.rotation) as GameObject;
            //ins = Instantiate(fruits[Random.Range(0, fruits.Length)], transform.position + new Vector3(x, 1.33f, z), Quaternion.Euler(0.0f, 0.0f, 0.0f)) as GameObject;
            ins = Instantiate(fruits[Random.Range(0, fruits.Length)], transform.position+ new Vector3(x, y, 1.33f), Quaternion.Euler(0.0f, 2.0f, 0.0f)) as GameObject;
            //ins.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
        }
        else
        {
            ins = Instantiate(bomb, transform.position + new Vector3(1, 1, 1), Random.rotation) as GameObject;
            //ins = Instantiate(bomb) as GameObject;
        }
        //float power = Random.Range(1.5f, 1.8f) * -Physics.gravity.y * 1.5f * powerScale;
        // float power = powerScale;
        //Vector3 direction = new Vector3(-x * 0.05f * Random.Range(0.3f, 0.8f), 1, 0);
        //Vector3 direction = new Vector3(0, 0, 1);
       // direction.z = 1f;
        //ins.GetComponent<Rigidbody>().velocity = direction * power;
       // ins.GetComponent<Rigidbody>().AddForce(Random.onUnitSphere * 0.1f, ForceMode.Force);
       // ins.GetComponent<Rigidbody>().AddForce(direction, ForceMode.Force);
        //ins.GetComponent<Rigidbody>().transform.Translate(0, 0, 10f * Time.deltaTime);
    }

    //void OnTriggerEnter(Collider other)
    void OnTriggerEnter(Collider other)
    {
        Destroy(other.gameObject);
        
    }
}
