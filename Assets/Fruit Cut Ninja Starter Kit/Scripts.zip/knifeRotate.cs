﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class knifeRotate : MonoBehaviour
{
    Vector3 pos=new Vector3(0f, 0f, 1f);
    // Start is called before the first frame update
    private Transform weizhi;
    void Start()
    {
        weizhi = gameObject.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKey(KeyCode.A))
        {
            //this.transform.rotation = Quaternion.AngleAxis(90, Vector3.up*Time.deltaTime*20);
            transform.RotateAround(new Vector3(-1.696f, 1.144f, 4.589f), new Vector3(1f, 0f, 0f), 5f*Time.deltaTime*100);
            //transform.Rotate(pos, 60f);
        }
        if(Input.GetKey(KeyCode.D))
        {
            //transform.Rotate(new Vector3(0, 30*Time.deltaTime, 0));
            //this.transform.rotation = Quaternion.AngleAxis(-90, Vector3.up * Time.deltaTime);
            transform.RotateAround(new Vector3(-1.696f, 1.144f, 4.589f), new Vector3(1f, 0f, 0f), -5f*Time.deltaTime*100);
        }
    }
}
