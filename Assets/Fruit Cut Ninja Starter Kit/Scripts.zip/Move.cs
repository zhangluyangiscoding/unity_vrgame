﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed = 0.00005f;
    GameObject ins;
    float perTime = 2f;
    float start = 0f;
    int number;
    // Update is called once per frame
    private void Start()
    {
        number = Random.Range(0, 2);
    }
    void Update()
    {
        start += Time.deltaTime;
        if (start >= perTime)
        {
            //transform.Translate(0, 0, -speed * Time.deltaTime);
            if (number == 0)
            {
                transform.Translate(-speed * Time.deltaTime, 0,0);
            }else if (number == 1)
            {
                transform.Translate( speed * Time.deltaTime,0, 0);
            }
        }
        
       // transform.Translate(0,0, speed * Time.deltaTime);
    //    ins.GetComponent<Rigidbody>().AddForce(new Vector3(speed,0,0));
    }

}
