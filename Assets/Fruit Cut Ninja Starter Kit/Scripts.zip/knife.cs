﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class knife : MonoBehaviour
{
    Vector2 screenInp;
    bool fire = false;
    bool fire_prev = false;
    bool fire_down = false;
    bool fire_up = false;
    public LineRenderer trail;
    Vector2 start, end;
    Vector3[] trailPositions = new Vector3[10];
    int index;
    float lineTimer = 1.0f;
    int linePart = 0;
    public int points;
    float trail_alpha = 0f;
    int raycastCount = 10;
    bool started = false;
    //水果汁预制品
    public GameObject[] splashPrefab;
    public GameObject[] splashFlatPrefab;
    RaycastHit hit;
    Collision collision;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
            //OnCollisionEnter(collision);
        
        //if (hit.collider.gameObject.tag != "destroyed"&&a==1)
        //{
        //    //生成切开水果的部分
        //    hit.collider.gameObject.GetComponent<ObjectKill>().OnKill();

        //    //删除切掉的水果
        //    Destroy(hit.collider.gameObject);


        //    //准备破开的水果的资源
        //    if (hit.collider.tag == "red") index = 0;
        //    if (hit.collider.tag == "yellow") index = 1;
        //    if (hit.collider.tag == "green") index = 2;
        //    //水果汁效果
        //    Vector3 splashPoint = hit.point;
        //    splashPoint.z = 4;
        //    Instantiate(splashPrefab[index], splashPoint, Quaternion.identity);
        //    splashPoint.z += 4;
        //    Instantiate(splashFlatPrefab[index], splashPoint, Quaternion.identity);

        //    //切到炸弹
        //    if (hit.collider.gameObject.tag != "bomb") points++; else points -= 5;
        //    points = points < 0 ? 0 : points;
        //    hit.collider.gameObject.tag = "destroyed";
        //}
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "default"|| collision.gameObject.name == "default1")
        {
            if (this.gameObject.tag != "destroyed")
            {
                //生成切开水果的部分
                this.gameObject.GetComponent<ObjectKill>().OnKill();

                //删除切掉的水果
                Destroy(this.gameObject);


                //准备破开的水果的资源
                if (this.tag == "red") index = 0;
                if (this.tag == "yellow") index = 1;
                if (this.tag == "green") index = 2;
                //水果汁效果
                Vector3 splashPoint =transform.position;
                splashPoint.z = 4;
                Instantiate(splashPrefab[index], splashPoint, Quaternion.identity);
                splashPoint.z += 4;
                Instantiate(splashFlatPrefab[index], splashPoint, Quaternion.identity);

                //切到炸弹
                //if (hit.collider.gameObject.tag != "bomb") points++; else points -= 5;
                //points = points < 0 ? 0 : points;
                //hit.collider.gameObject.tag = "destroyed";
            }
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        
    }

    private void OnCollisionStay(Collision collision)
    {
        
    }
}
