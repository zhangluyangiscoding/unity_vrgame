﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    bool run = false;
    bool showTimeLeft = true;
    bool timeEnd = false;
    float startTime = 0.0f;
    float curTime = 0.0f;
    string curStrTime = string.Empty;
    bool pause = false;
    public float timeAvailable = 30f;
    public float showTime = 0;
    public Text guiTimer;
    public GameObject finishedUI;
    // Start is called before the first frame update
    private void Start()
    {
        RunTimer();
    }
    public void RunTimer()
    {
        run = true;
        startTime = Time.time;

    }
    public void PauseTimer(bool b)
    {
        pause = b;
    }
    public void EndTimer()
    {

    }
    // Update is called once per frame
    void Update()
    {
        if(pause)
        {
            startTime = startTime + Time.deltaTime;
            return;
        }
        if (run)
        {
            curTime = Time.time - startTime;

        }
        if(showTimeLeft)
        {
            showTime = timeAvailable - curTime;
            if(showTime<=0)
            {
                timeEnd = true;
                showTime = 0;
                //Application.Quit();
                //弹出界面，告诉用户游戏结束并且暂停游戏
                finishedUI.SetActive(true);
            }
            int minutes = (int)(showTime / 60);
            int seconds = (int)(showTime % 60);
            int fraction = (int)((showTime * 100) % 100);
            curStrTime = string.Format("{0:00}:{1:00}:{2:00}", minutes, seconds, fraction);
            guiTimer.text = "Time:" + curStrTime;

        }
    }
}
