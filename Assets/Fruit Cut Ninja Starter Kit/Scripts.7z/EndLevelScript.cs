﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EndLevelScript : MonoBehaviour
{
    public void EndGame()
    {
        Application.Quit();
    }
}
